//
//  DIStartupViewController.h
//  Diddit
//
//  Created by Matthew Holcombe on 02.02.12.
//  Copyright (c) 2012 Sparkle Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DIStartupViewController : UIViewController

@end
