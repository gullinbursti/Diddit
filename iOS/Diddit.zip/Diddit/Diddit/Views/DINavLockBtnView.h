//
//  DINavLockBtnView.h
//  Diddit
//
//  Created by Matthew Holcombe on 02.01.12.
//  Copyright (c) 2012 Sparkle Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DINavLockBtnView : UIView {
	UIButton *_btn;
}

@property (nonatomic, retain) UIButton *btn;

@end
