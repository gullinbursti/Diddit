//
//  DINavHomeIcoBtnView.h
//  Diddit
//
//  Created by Matthew Holcombe on 01.09.12.
//  Copyright (c) 2012 Sparkle Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DINavHomeIcoBtnView : UIView {
	UIButton *_btn;
}

@property (nonatomic, retain) UIButton *btn;

@end
