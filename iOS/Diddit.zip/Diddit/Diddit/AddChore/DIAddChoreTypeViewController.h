//
//  DIAddChoreTypeViewController.h
//  DidIt
//
//  Created by Matthew Holcombe on 12.12.11.
//  Copyright (c) 2011 Sparkle Mountain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DIAddChoreTypeViewController : UIViewController {
	UILabel *_titleLbl;
}

@end
